import Padre from "../Padre/Padre"

const Abuelo = () => {
  return (
    <Padre />
  )
}

export default Abuelo
