import Hijo from "../Hijo/Hijo"

const Padre = () => {
    return (
        <Hijo />
    )
}

export default Padre
