import './App.css';
import Abuelo from './componentes/Abuelo/Abuelo';
import { Contexto } from './context/context';

function App() {

  const herencia = {
    efectivo: 10000000,
    propiedades: 6,
    vehiculos: 5
  };

  return (
    <div className="App">
      <Contexto.Provider value={herencia}>
        <Abuelo />
      </Contexto.Provider>
    </div>
  );
}

export default App;
