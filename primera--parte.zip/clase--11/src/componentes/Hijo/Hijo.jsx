//UTILIZANDO EL HOOK USECONTEXT

import { Contexto } from "../../context/context";
import { useContext } from "react";


const Hijo = () => {
    const herencia = useContext(Contexto);
    return (
        <div>
            <p>Mi herencia es de: {herencia.efectivo} </p>
            <p>Recibi estos vehiculos: {herencia.vehiculos} </p>
            <p>Y esta cantidad de propiedades: {herencia.propiedades} </p>
        </div>
    )
}

export default Hijo;









//////////////////////////////////////////////////////
//UTILIZANDO EL CONSUMER: 

/*
import React from 'react'
import { Contexto } from '../../context/context'

const Hijo = () => {
    return (
        <Contexto.Consumer>
            {
                (herencia) => (
                    <div>
                        <p>Mi herencia es de: {herencia.efectivo} </p>
                        <p>Recibi estos vehiculos: {herencia.vehiculos} </p>
                        <p>Y esta cantidad de propiedades: {herencia.propiedades} </p>
                    </div>

                )
            }
        </Contexto.Consumer>
    )
}

export default Hijo

*/

